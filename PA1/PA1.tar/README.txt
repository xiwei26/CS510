Befor running the program:
	Put the video file in the same directory as the source file.
	Please convert .mov to .ogv file using this website: https://convertio.co/mov-ogv/

To run the program:
	python a1.py <in_file> <out_file>
	eg: python a1.py example1.ogv output

The name of in_file should be *.ogv
The name of out_file should be *
Due to the department machine environment, it only allows us to use .ogv file as input file and we decided to make the format of output file as .avi in default. However, all formats work in our own macbook. If necessary, we can demo using the same code with different input file formats such as .mp4 and .mov.
